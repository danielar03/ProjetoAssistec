package br.com.loja.Assitec.dal;

public class ModuloConexao {

}
