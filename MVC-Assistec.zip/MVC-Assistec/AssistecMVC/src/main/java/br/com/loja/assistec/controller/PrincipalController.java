package br.com.loja.assistec.controller;

public class PrincipalController {

}