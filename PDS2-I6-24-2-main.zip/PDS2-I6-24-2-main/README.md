# PDS2-I6-24-2

Este repositório tem o objetivo de disponibilizar os códigos utilizados nas aulas de Práticas de Desenvolvimento de Software 2.
